const CACHE='bell-performance-2-1-v1';
const ASSETS=[
  './','./index.html','./manifest.json','./css/app.css',
  './data/workouts.js','./js/storage.js','./js/readiness.js',
  './js/mobility.js','./js/nutrition.js','./js/milestones.js',
  './js/workouts.js','./js/ui.js','./js/app.js'
];

self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request)
      .then(response => {
        const copy = response.clone();
        caches.open(CACHE).then(cache => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
